import { createElement, Fragment, FunctionComponent, useRef } from 'react';
import { BryntumDemoHeader, BryntumGantt } from '@bryntum/gantt-react';
import { ganttProps } from './GanttConfig';
import './App.scss';

const App: FunctionComponent = () => {
  const gantt = useRef<BryntumGantt>(null);

  return (
        <Fragment>
            <BryntumDemoHeader/>
            <BryntumGantt ref={gantt} {...ganttProps} />
        </Fragment>
    );
};

export default App;
