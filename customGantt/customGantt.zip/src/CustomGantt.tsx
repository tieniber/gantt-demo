import { ReactElement, createElement, Fragment, /*FunctionComponent,*/ useRef/*, useCallback*/ } from "react";

import { BryntumDemoHeader, BryntumGantt } from '@bryntum/gantt-react';
import { ganttProps } from './GanttConfig';
import './App.scss';

//import { CustomGanttContainerProps } from "../typings/CustomGanttProps";
//import { BadgeSample } from "./components/BadgeSample";
import "./ui/CustomGantt.css";

export function CustomGantt(/*props: CustomGanttContainerProps*/): ReactElement {
    const gantt = useRef<BryntumGantt>(null);

    // const { customganttType, customganttValue, valueAttribute, onClickAction, style, bootstrapStyle } = props;
    // const onClickHandler = useCallback(() => {
    //     if (onClickAction && onClickAction.canExecute) {
    //         onClickAction.execute();
    //     }
    // }, [onClickAction]);

    return (
            <Fragment>
                <BryntumDemoHeader/>
                <BryntumGantt ref={gantt} {...ganttProps} />
            </Fragment>
        // <BadgeSample
        //     type={customganttType}
        //     bootstrapStyle={bootstrapStyle}
        //     className={props.class}
        //     clickable={!!onClickAction}
        //     defaultValue={customganttValue ? customganttValue : ""}
        //     onClickAction={onClickHandler}
        //     style={style}
        //     value={valueAttribute ? valueAttribute.displayValue : ""}
        // />
    );
}

