import { ReactElement, createElement } from "react";
import classNames from "classnames";

export interface AlertProps {
    message?: string;
    className?: string;
    bootstrapStyle: "default" | "primary" | "success" | "info" | "inverse" | "warning" | "danger";
}

export function Alert({ message, className, bootstrapStyle }: AlertProps): ReactElement | null {
    return message ? <div className={classNames(`alert alert-${bootstrapStyle}`, className)}>{message}</div> : null;
}
