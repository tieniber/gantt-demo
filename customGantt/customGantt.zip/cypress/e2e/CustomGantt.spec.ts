describe("CustomGantt", () => {
    it("changes caption when attribute value is changed", () => {
        cy.visit("/");

        /**
        * Create here your tests, Example:
        * const newAttributeValue = "Test";
        * const badge = ".mx-name-badgeDanger";
        *
        * cy.get(badge).should("not.contain.text", newAttributeValue);
        * cy.get(".mx-name-dataInput").find("input").type(newAttributeValue).type("{enter}");
        * cy.get(badge).should("contain.text", newAttributeValue);
        **/
    });
});
